-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2017 at 03:48 PM
-- Server version: 5.7.11
-- PHP Version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `2017_projet3_vente`
--
CREATE DATABASE IF NOT EXISTS `2017_projet3_vente` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `2017_projet3_vente`;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `ctid` int(11) NOT NULL,
  `nom` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `categories`
--

INSERT INTO `categories` (`ctid`, `nom`) VALUES
(1, 'Humour'),
(2, 'Scolaire'),
(3, 'Theatre'),
(4, 'Romance'),
(5, 'SF,Fantasy'),
(6, 'Sport,Loisirs'),
(7, 'Guides'),
(8, 'Cuisine'),
(9, 'Histoires'),
(10, 'Littetature'),
(11,'Informatique,Internet');


-- --------------------------------------------------------

--
-- Table structure for table `commande`
--
DROP TABLE IF EXISTS `commande`;
CREATE TABLE `commande` (
  `cmdid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `qte` int(10) UNSIGNED NOT NULL,
  `date` datetime NOT NULL,
  `statut` enum('en_cours','acceptee','refusee','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `commandes`
--

INSERT INTO `commande` (`cmdid`,`pid`,`uid`,`qte`,`date`, `statut`) VALUES
(120, 110, 3,1,'2017-05-01 10:00:00','refusee'),
(121, 113, 3,2,'2017-04-19 13:03:00', 'en_cours'),
(122, 114, 4,1,'2017-04-17 17:16:00','en_cours'),
(123, 116, 4,2,'2017-04-27 13:25:00','acceptee'),
(124, 117, 3,1,'2017-04-23 10:21:57','en_cours');

-- --------------------------------------------------------

--
-- Table structure for table `produits`
--
DROP TABLE IF EXISTS `produits`;
CREATE TABLE `produits` (
  `pid` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `qte` int(11) UNSIGNED NOT NULL,
  `prix` float UNSIGNED NOT NULL,
  `uid` int(11) NOT NULL,
  `ctid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Contenu de la table `produits`
--

INSERT INTO `produits` (`pid`, `nom`, `description`, `qte`, `prix`, `uid`, `ctid`) VALUES
(110, 'PHP 7', 'Cours et exercices',5, 25, 5, 11),
(111, 'HTML & CSS','Premiers pas en CSS3 et HTML5', 7, 16.90, 5,11),
(112, 'Star Wars Rogue One', 'Novel de James Luceno', 5, 8.99, 5, 5),
(113, 'Antigone', 'Jean Anouilh piece theatre', 3, 5.40, 5, 3),
(114, 'Code de la route 2017', 'Cours et test', 9, 12.20, 6, 7),
(115, 'Le Pere Goriot', 'Balzac Text integral GF Flammarion', 8, 7.99, 6, 10),
(116, 'Elle et lui ', 'Marc Levy edition Pocket', 3, 5.60, 6, 4),
(117,'Harry Potter 1','Ecole des sorciers JK Rowling',10,4.50,6,5),
(118,'Harry Potter 2','La chambre des secrets',10,5.50,6,5),
(119,'Harry Potter 3','Le prisonnier d Azkaban JK Rowling',10,7,6,5),
(120,'Art de la guerre','Poche 2015',3,6.50,6,9),
(121,'Maths 1ere annee','Licences DUT/IUT PREPA',10,26,6,2),
(122,'Humour du jour','Chaque jour une blague',2,3,6,1),
(123,'Fitness','80 jours de remise en forme',1,18,5,6),
(124,'Saveur Asie','30 recettes de plats asiatiques',2,23,5,8),
(125,'Saveur Afrique','30 recettes de plats africains',3,23.5,5,8);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `nom` varchar(30) DEFAULT NULL,
  `prenom` varchar(30) DEFAULT NULL,
  `login` varchar(30) NOT NULL,
  `mdp` varchar(255) NOT NULL,
  `role` enum('acheteur','vendeur') NOT NULL DEFAULT 'acheteur'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `nom`, `prenom`, `login`, `mdp`, `role`) VALUES
(3, 'Acheteur', '1', 'a1', '$2y$10$P8G..ohvFEfqLNoKrNrAWuMWZBnh/P/mREJrOlGurLAgXJ/G8IxIC', 'acheteur'),
(4, 'Acheteur', '2', 'a2', '$2y$10$EE7Bopz3kPquQfefWBM20us2khBlCV6B8ADspyjAFf5g04XsKfI5m', 'acheteur'),
(5, 'Vendeur', '1', 'v1', '$2y$10$pL0lHn0pdrBoM0kJWjsdT.Av70yFTF287x5OAKcp9WAdGgN5X4/Rq', 'vendeur'),
(6, 'Vendeur', '2', 'v2', '$2y$10$LFIX4541UmeDSSkNxXxKUuQfPBPqfBlE5/v7mm2pbIvgtUqrdoXie', 'vendeur');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`ctid`);

--
-- Indexes for table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`cmdid`),
  ADD KEY `pid` (`pid`) USING BTREE,
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `produits`
--
ALTER TABLE `produits`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `ctid` (`ctid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `login` (`login`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `ctid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `commande`
--
ALTER TABLE `commande`
  MODIFY `cmdid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `produits`
--
ALTER TABLE `produits`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `commande_ibfk_2` FOREIGN KEY (`pid`) REFERENCES `produits` (`pid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `produits`
--
ALTER TABLE `produits`
  ADD CONSTRAINT `produits_ibfk_1` FOREIGN KEY (`ctid`) REFERENCES `categories` (`ctid`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
